﻿///script/ActivityTimer.js
var _sOrgName = "";
var entityName = "";
var date = "";
var serverUrl = "";
var sav_regardingid = "";
var myVar = "";
function onLoad()
{
	//debugger;
	date = new Date();
	document.getElementById('lbl_start').innerHTML = GetFormattedDate(new Date());
	sav_regardingid = window.parent.Xrm.Page.data.entity.getId();
	if (sav_regardingid == null || sav_regardingid == "" || sav_regardingid == undefined) {
		window.parent.Xrm.Page.data.entity.addOnSave(setID);
	}
	else {
		document.getElementById('lbl_last').innerHTML = getlast();
		document.getElementById('lbl_total').innerHTML = getTotal();
	}
	entityName = window.parent.Xrm.Page.data.entity.getEntityName()
	serverUrl = window.parent.Xrm.Page.context.getClientUrl();
	
}
function getlast() {
	if (sav_regardingid != "") {
		FetchXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' top='1'  distinct='false'>" +
"  <entity name='sav_timelog'>" +
"    <attribute name='sav_timelogid' />" +
"    <attribute name='sav_starttime' />" +
"    <order attribute='createdon' descending='true' />" +
"    <filter type='and'>" +
"      <condition attribute='sav_regardingid' operator='eq' value='"+sav_regardingid+"' />" +
"    </filter>" +
"  </entity>" +
"</fetch>";
		_oService = new FetchUtil(_sOrgName, serverUrl);
		var results = _oService.Fetch(FetchXml);
		if (results.length > 0) {
			return results[0].attributes.sav_starttime.formattedValue;
		}
		else
			return "";
	}
}
function getTotal() {
	var units = {
		"hour":  60*60,
		"minute":60,
		"second":1
	}

	var result = []

	
	if (sav_regardingid != "") {
		FetchXml = "<fetch version='1.0' aggregate='true' >" +
"  <entity name='sav_timelog' >" +
 "    <attribute name='sav_timedifference' alias='TimeDiff' aggregate='sum'  /> />" +
"    <filter type='and' >" +
"      <condition attribute='sav_regardingid' operator='eq' value='" + sav_regardingid + "' />" +
"    </filter>" +
"  </entity>" +
"</fetch>";
		_oService = new FetchUtil(_sOrgName, serverUrl);
		var results = _oService.Fetch(FetchXml);
		if (results.length > 0) {
			var value = results[0].attributes.TimeDiff.formattedValue;
			for (var name in units) {
				var p = Math.floor(value / units[name]);
				if (p == 1) result.push(p + " " + name);
				if (p >= 2) result.push(p + " " + name + "s");
				value %= units[name]

			}
			return result;
		}
		else
			return "0Hr:0Min:0Sec";
	}
	
}
function setID() {
	 myVar = setInterval(function () { myTimer() }, 3000);
}
function myTimer() {
	sav_regardingid = window.parent.Xrm.Page.data.entity.getId();
	if (sav_regardingid != "") {
		clearInterval(myVar);

	}
}
function onbeforeUnload() {
	alert('test');
	debugger;
	//create record
	if (sav_regardingid != "" ) {
		var sav_timelog = {};
		sav_timelog.sav_name = entityName+" : " + date.toString();
		sav_timelog.sav_startTime = date;
		sav_timelog.sav_regardingid = sav_regardingid;
		if (sav_timelog.sav_starttime == "") {
			return;
		}
		_oService = new FetchUtil(_sOrgName, serverUrl);
		_oService.createRecord(sav_timelog, "sav_timelog", function (sav_timelogResult) { }, errorHandler, false);
	}
}
function sav_timelogResult(result)
{

}
function errorHandler(error) {
	writeMessage(error.message);
}
function GetFormattedDate(date) {
	var year = date.getFullYear();

	var month = (1 + date.getMonth()).toString();
	month = month.length > 1 ? month : '0' + month;

	var day = date.getDate().toString();
	day = day.length > 1 ? day : '0' + day;

	var hour = date.getHours();
	var min = date.getMinutes();
	var second = date.getSeconds();
	return month + "/" + day + "/" + year + "::" + hour + ":" + min + ":" + second ;
}